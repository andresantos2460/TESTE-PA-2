#ifndef _COMUM_H_
#ifndef _COMUM_H_
#define _COMUM_H_

#define ERR_ARGS 1
#define MAX_BUFFER 255


/*
 * definicoes, estruturas comuns ao cliente e ao servidor
 */

#endif
#define _COMUM_H_

#define ERR_ARGS 1
#define MAX_BUFFER 255


/*
 * definicoes, estruturas comuns ao cliente e ao servidor
 */

#endif
